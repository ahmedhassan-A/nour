import { Link } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, Search } from "lucide-react";
import HeroSection from "@/components/ui/hero-section";

const NotFound = () => {
  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, []);

  return (
    <HeroSection>
      <Card className="max-w-md mx-auto shadow-elegant backdrop-blur-sm bg-white/95 animate-fade-in-scale">
        <CardContent className="p-8 text-center">
          <div className="text-6xl font-bold text-primary mb-4">404</div>
          <h1 className="text-2xl font-bold mb-4">الصفحة غير موجودة</h1>
          <p className="text-muted-foreground mb-6">
            عذراً، الصفحة التي تبحث عنها غير متاحة
          </p>
          
          <div className="space-y-3">
            <Button asChild variant="hero" className="w-full">
              <Link to="/">
                <Home className="ml-2 h-4 w-4" />
                العودة للرئيسية
              </Link>
            </Button>
            
            <Button variant="outline" asChild className="w-full">
              <Link to="/">
                <Search className="ml-2 h-4 w-4" />
                اكتشف يوم ميلادك
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </HeroSection>
  );
};

export default NotFound;
