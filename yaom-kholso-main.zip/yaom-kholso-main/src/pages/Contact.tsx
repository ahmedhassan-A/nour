import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Send, Phone, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import HeroSection from "@/components/ui/hero-section";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "تم الإرسال بنجاح! ✅",
        description: "سنتواصل معك في أقرب وقت ممكن",
      });
      
      setFormData({ name: "", email: "", message: "" });
      setIsSubmitting(false);
    }, 1000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <>
      <HeroSection className="min-h-[50vh]">
        <div className="text-white">
          <h1 className="text-5xl font-bold mb-6 animate-fade-down">
            تواصل معنا
          </h1>
          <p className="text-xl mb-8 opacity-90">
            نحب أن نسمع منك! شاركنا رأيك أو استفساراتك
          </p>
        </div>
      </HeroSection>

      <div className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-elegant animate-fade-in-scale">
              <CardHeader>
                <CardTitle className="text-2xl text-center">أرسل رسالة</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2 animate-fade-in-scale animate-stagger-1">
                    <Label htmlFor="name">الاسم</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="اسمك الكريم..."
                      required
                    />
                  </div>

                  <div className="space-y-2 animate-fade-in-scale animate-stagger-2">
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      required
                    />
                  </div>

                  <div className="space-y-2 animate-fade-in-scale animate-stagger-3">
                    <Label htmlFor="message">الرسالة</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="اكتب رسالتك هنا..."
                      rows={5}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="hero"
                    className="w-full animate-fade-in-scale animate-stagger-4"
                    disabled={isSubmitting}
                  >
                    <Send className="ml-2 h-4 w-4" />
                    {isSubmitting ? "جاري الإرسال..." : "إرسال الرسالة"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="space-y-8">
              <Card className="shadow-card animate-fade-in-scale animate-stagger-1">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">البريد الإلكتروني</h3>
                      <p className="text-muted-foreground">drhmdhassan@gmail.com</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-card animate-fade-in-scale animate-stagger-2">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">الهاتف</h3>
                      <p className="text-muted-foreground">متاح قريباً</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-card animate-fade-in-scale animate-stagger-3">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">الموقع</h3>
                      <p className="text-muted-foreground">مصر 🇪🇬</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Call to Action */}
              <Card className="shadow-special bg-gradient-primary text-white animate-fade-in-scale animate-stagger-4">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-bold mb-2">لديك فكرة رائعة؟</h3>
                  <p className="mb-4 opacity-90">شاركها معنا في صفحة الأفكار</p>
                  <Button variant="secondary" asChild>
                    <a href="/ideas">ضع فكرتك</a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;