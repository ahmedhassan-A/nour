
import { useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Scroll, Users, BarChart3, Share2, Heart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

/**
 * Results page
 * - Reads ?name=...&date=YYYY-MM-DD
 * - Fetches:
 *    - Wikipedia OnThisDay events for month/day
 *    - Wikipedia OnThisDay births for month/day
 *    - Numbers API trivia for month/day
 *
 * Notes:
 * - We only use month and day from the submitted date (user asked: "جلب ما حدث في نفس اليوم والشهر")
 * - CORS: Wikipedia REST API supports cross-origin requests. Numbers API also supports JSON responses.
 */

type WikiEvent = {
  text: string;
  year: number;
  pages?: Array<{ normalizedtitle?: string; content_urls?: any }>;
};

const Results = () => {
  const [searchParams] = useSearchParams();
  const name = (searchParams.get("name") || "").trim();
  const date = searchParams.get("date") || "";
  const { toast } = useToast();

  const [events, setEvents] = useState<WikiEvent[]>([]);
  const [births, setBirths] = useState<WikiEvent[]>([]);
  const [trivia, setTrivia] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showSpecialMessage, setShowSpecialMessage] = useState(false);

  // Special-name logic: name is exactly "نور" or starts with "نور "
  const lcName = name.toLowerCase();
  const isSpecialName = lcName === "نور" || lcName.startsWith("نور ");

  useEffect(() => {
    if (isSpecialName) {
      const timer = setTimeout(() => {
        setShowSpecialMessage(true);
      }, 1200);
      return () => clearTimeout(timer);
    } else {
      setShowSpecialMessage(false);
    }
  }, [isSpecialName]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      setEvents([]);
      setBirths([]);
      setTrivia("");

      if (!date) {
        setError("لم يتم إرسال تاريخ صالح.");
        setLoading(false);
        return;
      }

      // parse YYYY-MM-DD
      const parts = date.split("-");
      if (parts.length < 2) {
        setError("تنسيق التاريخ غير صالح. استخدم YYYY-MM-DD.");
        setLoading(false);
        return;
      }
      const month = parseInt(parts[1], 10);
      const day = parseInt(parts[2], 10);

      try {
        // Wikipedia REST: onthisday events and births
        const base = "https://en.wikipedia.org/api/rest_v1/feed/onthisday";
        const [eventsRes, birthsRes] = await Promise.all([
          fetch(`${base}/events/${month}/${day}`),
          fetch(`${base}/births/${month}/${day}`)
        ]);

        if (!eventsRes.ok) throw new Error("فشل جلب الأحداث من ويكيبيديا");
        if (!birthsRes.ok) throw new Error("فشل جلب مواليد اليومية من ويكيبيديا");

        const eventsJson = await eventsRes.json();
        const birthsJson = await birthsRes.json();

        // eventsJson.events is the array of events
        const fetchedEvents: WikiEvent[] = (eventsJson.events || []).map((e: any) => ({
          text: e.text,
          year: e.year,
          pages: e.pages
        }));

        const fetchedBirths: WikiEvent[] = (birthsJson.births || []).map((b: any) => ({
          text: b.text,
          year: b.year,
          pages: b.pages
        }));

        setEvents(fetchedEvents);
        setBirths(fetchedBirths);

        // Numbers API for trivia about the date
        try {
          const numRes = await fetch(`http://numbersapi.com/${month}/${day}/date?json`);
          if (numRes.ok) {
            const numJson = await numRes.json();
            setTrivia(numJson.text || "");
          }
        } catch (e) {
          // ignore if numbersapi fails (CORS or network)
        }

      } catch (err: any) {
        console.error(err);
        setError(err.message || "حدث خطأ أثناء جلب البيانات.");
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [date]);

  const handleShare = () => {
    const shareText = `اكتشفت ما حدث في يوم ميلادي! تعال واكتشف أنت أيضاً: ${window.location.href}`;
    if ((navigator as any).share) {
      (navigator as any).share({ title: "يوم ميلادي", text: shareText, url: window.location.href });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({ title: "تم نسخ رابط المشاركة", description: "الصق الرابط في أي مكان لمشاركته" });
    }
  };

  // small helper to render a wiki item
  const renderItem = (item: WikiEvent) => {
    return (
      <div key={item.year + "-" + item.text.slice(0,20)} className="p-3 rounded-lg bg-background/20">
        <Badge variant="secondary" className="mb-2">{item.year}</Badge>
        <p className="text-sm">{item.text}</p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">نتائج البحث</h2>
        <div className="flex items-center gap-2">
          <Button onClick={handleShare} variant="ghost" size="sm">
            <Share2 className="ml-2 h-4 w-4" />
            شارك
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>معلومات عن {name || "هذا التاريخ"}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-3 text-sm">
            {date ? `التاريخ: ${date}` : "لم يتم توفير تاريخ."}
          </p>

          {loading && <p>جاري جلب المعلومات من مصادر موثوقة...</p>}
          {error && <p className="text-red-500">{error}</p>}

          {!loading && !error && (
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Scroll /> الأحداث التاريخية</h3>
                {events.length ? events.slice(0,6).map(renderItem) : <p>لا توجد أحداث مسجلة لهذا اليوم.</p>}
              </div>

              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Users /> مشاهير مولودون</h3>
                {births.length ? births.slice(0,8).map(renderItem) : <p>لا توجد بيانات عن مواليد لهذا اليوم.</p>}
              </div>

              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2"><BarChart3 /> معلومات وأرقام</h3>
                {trivia ? (
                  <div className="p-3 rounded-lg bg-background/20">
                    <p className="text-sm">{trivia}</p>
                  </div>
                ) : <p>لا توجد معلومات إضافية.</p>}
              </div>
            </div>
          )}

          {/* Special message for names starting with "نور" */}
          {isSpecialName && showSpecialMessage && (
            <div className="mt-6 p-4 rounded-lg" style={{ background: "linear-gradient(90deg,#ffefc6,#ffe1f0)" }}>
              <p className="text-lg font-semibold" dir="rtl">عرض خاص لـ {name}</p>
              <p className="mt-2 text-sm">نتمنى لك يوم ميلاد رائع 💖</p>
              <SpecialTypewriterMessage />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

// Simple typewriter effect component (no external libs)
const SpecialTypewriterMessage = () => {
  const fullText = "وأحمد حسن بيحبك ❤️";
  const [index, setIndex] = useState(0);

  useEffect(() => {
    setIndex(0);
    const id = setInterval(() => {
      setIndex(i => {
        if (i >= fullText.length) {
          clearInterval(id);
          return i;
        }
        return i + 1;
      });
    }, 80);
    return () => clearInterval(id);
  }, []);

  return (
    <p className="mt-3 text-xl font-bold" style={{ fontFamily: "Cairo, Tajawal, sans-serif" }}>
      {fullText.slice(0, index)}
      <span className="blink">|</span>
      <style>{`.blink{opacity:0;animation:blink 1s steps(1) infinite}@keyframes blink{50%{opacity:1}}`}</style>
    </p>
  );
};

export default Results;
