import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, Sparkles, Send, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import HeroSection from "@/components/ui/hero-section";

const Ideas = () => {
  const [formData, setFormData] = useState({
    name: "",
    idea: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "شكراً لك! 🌟",
        description: "تم إرسال فكرتك بنجاح، نقدر إبداعك!",
      });
      
      setFormData({ name: "", idea: "" });
      setIsSubmitting(false);
    }, 1000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const ideaExamples = [
    "إضافة ميزة معرفة الطقس في يوم الميلاد",
    "عرض الأغاني الشائعة في نفس العام",
    "إحصائيات عن الأحداث الرياضية",
    "معلومات عن الاختراعات في نفس السنة"
  ];

  return (
    <>
      <HeroSection className="min-h-[60vh]">
        <div className="text-white">
          <div className="flex items-center justify-center mb-6">
            <Lightbulb className="h-16 w-16 text-yellow-300 animate-pulse-slow ml-4" />
            <h1 className="text-5xl font-bold animate-fade-down">
              ضع فكرتك
            </h1>
          </div>
          <p className="text-xl mb-8 opacity-90">
            شاركنا أفكارك الإبداعية لتطوير الموقع وجعله أفضل
          </p>
        </div>
      </HeroSection>

      <div className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Ideas Form */}
            <Card className="shadow-elegant animate-fade-in-scale">
              <CardHeader>
                <CardTitle className="text-2xl text-center flex items-center justify-center space-x-2 space-x-reverse">
                  <Sparkles className="h-6 w-6 text-primary" />
                  <span>شارك فكرتك</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2 animate-fade-in-scale animate-stagger-1">
                    <Label htmlFor="name">اسمك</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="اسمك الكريم..."
                      required
                    />
                  </div>

                  <div className="space-y-2 animate-fade-in-scale animate-stagger-2">
                    <Label htmlFor="idea">فكرتك الرائعة</Label>
                    <Textarea
                      id="idea"
                      name="idea"
                      value={formData.idea}
                      onChange={handleChange}
                      placeholder="اكتب فكرتك بالتفصيل..."
                      rows={6}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="hero"
                    className="w-full animate-fade-in-scale animate-stagger-3"
                    disabled={isSubmitting}
                  >
                    <Send className="ml-2 h-4 w-4" />
                    {isSubmitting ? "جاري الإرسال..." : "إرسال الفكرة"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Ideas Examples & Inspiration */}
            <div className="space-y-8">
              <Card className="shadow-card animate-fade-in-scale animate-stagger-1">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 space-x-reverse">
                    <Zap className="h-5 w-5 text-primary" />
                    <span>أمثلة للإلهام</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {ideaExamples.map((example, index) => (
                      <div
                        key={index}
                        className="p-3 rounded-lg bg-primary/5 border border-primary/20 transition-colors hover:bg-primary/10"
                      >
                        <p className="text-sm">{example}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-special bg-gradient-primary text-white animate-fade-in-scale animate-stagger-2">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center space-x-2 space-x-reverse">
                    <Sparkles className="h-6 w-6" />
                    <span>لماذا نحتاج أفكارك؟</span>
                  </h3>
                  <ul className="space-y-2 opacity-90">
                    <li>• لجعل الموقع أكثر إفادة ومتعة</li>
                    <li>• لإضافة ميزات جديدة ومبتكرة</li>
                    <li>• لتحسين تجربة المستخدمين</li>
                    <li>• لبناء مجتمع إبداعي متفاعل</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="shadow-card animate-fade-in-scale animate-stagger-3">
                <CardContent className="p-6 text-center">
                  <div className="p-4 bg-special-gold/10 rounded-full w-fit mx-auto mb-4">
                    <Lightbulb className="h-8 w-8 text-special-gold" />
                  </div>
                  <h3 className="font-bold mb-2">فكرة ذهبية؟</h3>
                  <p className="text-muted-foreground text-sm">
                    الأفكار المميزة سيتم تنفيذها وذكر صاحبها
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Ideas;