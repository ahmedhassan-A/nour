import HeroSection from "@/components/ui/hero-section";
import BirthdayForm from "@/components/forms/BirthdayForm";

const Index = () => {
  return (
    <HeroSection>
      <h1 className="text-6xl font-bold text-white mb-6 animate-fade-down">
        اعرف ماذا حدث في يوم ميلادك؟
      </h1>
      <p className="text-xl text-white/90 mb-12 max-w-2xl mx-auto animate-fade-down">
        اكتشف الأحداث التاريخية المهمة والمشاهير الذين ولدوا في نفس يوم ميلادك، 
        واستمتع برحلة عبر الزمن مليئة بالمفاجآت الرائعة
      </p>
      
      <div className="animate-fade-in-scale">
        <BirthdayForm />
      </div>
    </HeroSection>
  );
};

export default Index;
