import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Calendar, MessageCircle, Lightbulb, Home } from "lucide-react";

const Navigation = () => {
  const location = useLocation();

  const navItems = [
    { name: "الرئيسية", path: "/", icon: Home },
    { name: "تواصل معنا", path: "/contact", icon: MessageCircle },
    { name: "ضع فكرتك", path: "/ideas", icon: Lightbulb },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 space-x-reverse">
            <Calendar className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-primary">اعرف يوم ميلادك</span>
          </Link>

          <div className="flex items-center space-x-2 space-x-reverse">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Button
                  key={item.path}
                  variant={isActive ? "default" : "ghost"}
                  asChild
                  className="space-x-1 space-x-reverse"
                >
                  <Link to={item.path}>
                    <Icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </Link>
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;