import { Heart, Mail } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-8 mt-16">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-4">
            <Heart className="h-5 w-5 text-special-pink animate-pulse-slow" />
            <p className="text-lg">
              صُنع بحب من أجل اكتشاف ذكرياتك الجميلة
            </p>
          </div>
          
          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-4">
            <Mail className="h-4 w-4" />
            <a 
              href="mailto:drhmdhassan@gmail.com"
              className="hover:text-special-gold transition-colors"
            >
              drhmdhassan@gmail.com
            </a>
          </div>

          <p className="text-primary-foreground/70">
            © 2024 اعرف يوم ميلادك. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;