import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface HeroSectionProps {
  children: ReactNode;
  className?: string;
  withAnimation?: boolean;
}

const HeroSection = ({ children, className, withAnimation = true }: HeroSectionProps) => {
  return (
    <section 
      className={cn(
        "min-h-screen flex items-center justify-center gradient-bg relative overflow-hidden",
        className
      )}
    >
      {/* Animated background overlay */}
      <div className="absolute inset-0 bg-black/10" />
      
      {/* Content */}
      <div 
        className={cn(
          "relative z-10 text-center px-4 max-w-4xl mx-auto",
          withAnimation && "animate-fade-down"
        )}
      >
        {children}
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 left-20 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
    </section>
  );
};

export default HeroSection;