import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Calendar as CalendarIcon, Edit3 } from "lucide-react";
import { cn } from "@/lib/utils";

const BirthdayForm = () => {
  const [name, setName] = useState("");
  const [useCalendar, setUseCalendar] = useState(false);
  
  // للتقويم
  const [selectedDate, setSelectedDate] = useState<Date>();
  
  // للحقول المنفصلة
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  
  const navigate = useNavigate();

  const months = [
    { value: "01", label: "يناير" },
    { value: "02", label: "فبراير" },
    { value: "03", label: "مارس" },
    { value: "04", label: "أبريل" },
    { value: "05", label: "مايو" },
    { value: "06", label: "يونيو" },
    { value: "07", label: "يوليو" },
    { value: "08", label: "أغسطس" },
    { value: "09", label: "سبتمبر" },
    { value: "10", label: "أكتوبر" },
    { value: "11", label: "نوفمبر" },
    { value: "12", label: "ديسمبر" }
  ];

  const generateYears = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear; i >= 1900; i--) {
      years.push(i.toString());
    }
    return years;
  };

  const generateDays = () => {
    const days = [];
    for (let i = 1; i <= 31; i++) {
      days.push(i.toString().padStart(2, '0'));
    }
    return days;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let dateString = "";
    
    if (useCalendar && selectedDate) {
      dateString = format(selectedDate, "yyyy-MM-dd");
    } else if (!useCalendar && day && month && year) {
      dateString = `${year}-${month}-${day}`;
    }
    
    if (name && dateString) {
      navigate(`/results?name=${encodeURIComponent(name)}&date=${dateString}`);
    }
  };

  const isFormValid = () => {
    if (!name) return false;
    if (useCalendar) return !!selectedDate;
    return !!(day && month && year);
  };

  return (
    <Card className="w-full max-w-md mx-auto shadow-elegant backdrop-blur-sm bg-white/95">
      <CardContent className="p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-base font-medium">
              الاسم
            </Label>
            <Input
              ref={(input) => input?.focus()}
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="أدخل اسمك..."
              className="text-lg py-3"
              required
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">
                تاريخ الميلاد
              </Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setUseCalendar(!useCalendar)}
                className="space-x-1 space-x-reverse text-primary hover:text-primary"
              >
                {useCalendar ? (
                  <>
                    <Edit3 className="h-4 w-4" />
                    <span>كتابة يدوية</span>
                  </>
                ) : (
                  <>
                    <CalendarIcon className="h-4 w-4" />
                    <span>اختيار من التقويم</span>
                  </>
                )}
              </Button>
            </div>

            {useCalendar ? (
              // تقويم
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-right font-normal py-3 text-lg",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="ml-2 h-5 w-5" />
                    {selectedDate ? (
                      format(selectedDate, "dd/MM/yyyy")
                    ) : (
                      <span>اختر التاريخ...</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) =>
                      date > new Date() || date < new Date("1900-01-01")
                    }
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            ) : (
              // حقول منفصلة
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="day" className="text-sm">اليوم</Label>
                  <Select value={day} onValueChange={setDay}>
                    <SelectTrigger id="day" className="py-3">
                      <SelectValue placeholder="اليوم" />
                    </SelectTrigger>
                    <SelectContent>
                      {generateDays().map((d) => (
                        <SelectItem key={d} value={d}>
                          {d}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="month" className="text-sm">الشهر</Label>
                  <Select value={month} onValueChange={setMonth}>
                    <SelectTrigger id="month" className="py-3">
                      <SelectValue placeholder="الشهر" />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map((m) => (
                        <SelectItem key={m.value} value={m.value}>
                          {m.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year" className="text-sm">السنة</Label>
                  <Select value={year} onValueChange={setYear}>
                    <SelectTrigger id="year" className="py-3">
                      <SelectValue placeholder="السنة" />
                    </SelectTrigger>
                    <SelectContent>
                      {generateYears().map((y) => (
                        <SelectItem key={y} value={y}>
                          {y}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          <Button
            type="submit"
            variant="hero"
            size="xl"
            className="w-full animate-bounce-in"
            disabled={!isFormValid()}
          >
            <Sparkles className="ml-2 h-5 w-5" />
            اعرف الآن
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default BirthdayForm;