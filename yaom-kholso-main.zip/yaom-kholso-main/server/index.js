import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import dotenv from "dotenv";
import nodemailer from "nodemailer";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// Helper proxy to Wikipedia OnThisDay
app.get("/api/onthisday/:month/:day", async (req, res) => {
  const { month, day } = req.params;
  try {
    const eventsRes = await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/${month}/${day}`);
    const birthsRes = await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/births/${month}/${day}`);
    const deathsRes = await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/deaths/${month}/${day}`);

    const events = await eventsRes.json();
    const births = await birthsRes.json();
    const deaths = await deathsRes.json();

    res.json({ events, births, deaths });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch from Wikipedia" });
  }
});

// Proxy to Numbers API for date trivia
app.get("/api/numbers/:month/:day", async (req, res) => {
  const { month, day } = req.params;
  try {
    const resp = await fetch(`http://numbersapi.com/${month}/${day}/date?json`);
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch from Numbers API" });
  }
});

// Endpoint to send email with submitted info
app.post("/api/send-email", async (req, res) => {
  const { name, date, type, message } = req.body;
  const to = process.env.EMAIL_TO;
  if (!to) return res.status(500).json({ error: "EMAIL_TO not configured on server" });

  // Build email body
  const html = `
    <h2>New submission from Yaom-Kholso</h2>
    <p><strong>Type:</strong> ${type || "result"}</p>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Date:</strong> ${date}</p>
    <p><strong>Message:</strong><br/>${message || "-"}</p>
  `;

  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });

    await transporter.sendMail({
      from: process.env.SMTP_USER,
      to,
      subject: `Yaom-Kholso: new ${type || 'submission'} from ${name}`,
      html
    });

    res.json({ ok: true });
  } catch (err) {
    console.error("Email send error:", err);
    res.status(500).json({ error: "Failed to send email" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Ensure you've copied server/.env.example -> server/.env and set SMTP creds and EMAIL_TO`);
});
